<?php

use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\AdminLaunchCampaignController;
use App\Http\Controllers\Admin\AdminMarketplaceController;
use App\Http\Controllers\Admin\AdminOrderController;
use App\Http\Controllers\Admin\AdminReferralController;
use App\Http\Controllers\Admin\AdminReportsController;
use App\Http\Controllers\Admin\AdminSettingsController;
use App\Http\Controllers\Admin\AdminTransactionController;
use App\Http\Controllers\Admin\AdminUserController;
use Illuminate\Support\Facades\Route;

// Admin auth
Route::prefix('auth')->group(function () {
    Route::post('login', [AdminAuthController::class, 'login']);

    Route::middleware(['auth:api', 'admin'])->group(function () {
        Route::get('me',      [AdminAuthController::class, 'me']);
        Route::post('logout', [AdminAuthController::class, 'logout']);
    });
});

// All protected admin routes
Route::middleware(['auth:api', 'admin'])->group(function () {

    // Dashboard
    Route::get('dashboard/overview', [AdminDashboardController::class, 'overview']);
    Route::get('dashboard/activity', [AdminDashboardController::class, 'activity']);

    // Users
    Route::get('users',                        [AdminUserController::class, 'index']);
    Route::get('users/{user}',                 [AdminUserController::class, 'show']);
    Route::post('users/{user}/suspend',        [AdminUserController::class, 'suspend']);
    Route::post('users/{user}/restore',        [AdminUserController::class, 'restore']);
    Route::post('users/{user}/wallet/adjust',  [AdminUserController::class, 'adjustWallet']);

    // Orders
    Route::get('orders',              [AdminOrderController::class, 'index']);
    Route::get('orders/{order}',      [AdminOrderController::class, 'show']);
    Route::post('orders/{order}/cancel', [AdminOrderController::class, 'cancel']);

    // Transactions
    Route::get('transactions', [AdminTransactionController::class, 'index']);

    // Referrals
    Route::get('referrals/stats', [AdminReferralController::class, 'stats']);
    Route::get('referrals',       [AdminReferralController::class, 'index']);

    // Reports
    Route::get('reports/revenue', [AdminReportsController::class, 'revenue']);
    Route::get('reports/orders',  [AdminReportsController::class, 'orders']);
    Route::get('reports/users',   [AdminReportsController::class, 'users']);

    // Settings
    Route::get('settings',           [AdminSettingsController::class, 'index']);
    Route::post('settings',          [AdminSettingsController::class, 'update']);
    Route::delete('settings/{key}',  [AdminSettingsController::class, 'destroy']);

    // ── Admin marketplace routes ──────────────────────────────────────────────
    Route::prefix('marketplace')->group(function () {
        Route::get('stats',                        [AdminMarketplaceController::class, 'stats']);
        Route::get('vendors',                      [AdminMarketplaceController::class, 'vendors']);
        Route::post('vendors/{id}/approve',        [AdminMarketplaceController::class, 'approveVendor']);
        Route::post('vendors/{id}/suspend',        [AdminMarketplaceController::class, 'suspendVendor']);
        Route::post('vendors/{id}/reject',         [AdminMarketplaceController::class, 'rejectVendor']);
        Route::get('services',                     [AdminMarketplaceController::class, 'services']);
        Route::post('services/{id}/approve',       [AdminMarketplaceController::class, 'approveService']);
        Route::post('services/{id}/reject',        [AdminMarketplaceController::class, 'rejectService']);
        Route::post('services/{id}/suspend',       [AdminMarketplaceController::class, 'suspendService']);
        Route::get('orders',                       [AdminMarketplaceController::class, 'orders']);
        Route::delete('orders/{id}',               [AdminMarketplaceController::class, 'deleteOrder']);
        Route::delete('services/{id}',             [AdminMarketplaceController::class, 'deleteService']);
        Route::get('disputes',                     [AdminMarketplaceController::class, 'disputes']);
        Route::post('disputes/{id}/resolve',       [AdminMarketplaceController::class, 'resolveDispute']);
        Route::get('payouts',                          [AdminMarketplaceController::class, 'payouts']);
        Route::post('payouts/{id}/approve',            [AdminMarketplaceController::class, 'approvePayout']);
        Route::post('payouts/{id}/mark-processing',    [AdminMarketplaceController::class, 'markPayoutProcessing']);
        Route::post('payouts/{id}/mark-paid',          [AdminMarketplaceController::class, 'markPayoutPaid']);
        Route::post('payouts/{id}/mark-failed',        [AdminMarketplaceController::class, 'markPayoutFailed']);
        Route::post('payouts/{id}/reject',             [AdminMarketplaceController::class, 'rejectPayout']);
        Route::get('supplier-reports',                 [AdminMarketplaceController::class, 'supplierReports']);
        Route::get('ledger',                           [AdminMarketplaceController::class, 'ledger']);
    });

    // ── Waitlist launch campaign ──────────────────────────────────────────────
    Route::get('launch-campaign',       [AdminLaunchCampaignController::class, 'index']);
    Route::post('launch-campaign/test', [AdminLaunchCampaignController::class, 'test'])->middleware('throttle:5,1');
    Route::middleware('admin:super_admin')->group(function () {
        Route::post('launch-campaign/sync',  [AdminLaunchCampaignController::class, 'sync'])->middleware('throttle:5,1');
        Route::post('launch-campaign/send',  [AdminLaunchCampaignController::class, 'send'])->middleware('throttle:5,1');
        Route::post('launch-campaign/retry', [AdminLaunchCampaignController::class, 'retry'])->middleware('throttle:5,1');
    });
});
